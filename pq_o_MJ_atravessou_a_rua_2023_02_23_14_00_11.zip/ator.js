//ator

let yAtor = 340;
let xAtor = 250;
let colisao = false
let meusPontos = 0;

function mostraAtor(){
  image(imagemDoAtor, xAtor, yAtor, 150, 60);
}
function mostraAtorReverso(){
  image(imagemDoAtorReverso, xAtor, yAtor, 150, 60);
}
function movimentaAtor(){
  if (keyIsDown(UP_ARROW)){
    yAtor -= 3;
  }
  if (keyIsDown(DOWN_ARROW)){
    if (podeSeMover()){
       yAtor += 3;
    }
  }
  if (keyIsDown(RIGHT_ARROW)){
    xAtor += 3;
  }
  if (keyIsDown(LEFT_ARROW)){
    xAtor -= 3;
    filter(INVERT);
    text("MOONWALK REVERSO", 300, 140);
    fill(153, 50, 204);
    textSize(40);
    textStyle(BOLD);
  }
   
}
  
function verificaColisao(){
  //collideRectRect(x, y, width, height, x2, y2, width2, height2 )
  for (let i = 0; i < imagemCarros.length; i = i + 1){
    colisao = collideRectRect(xCarros[i], yCarros[i], 0, 27, xAtor, yAtor, 80, 50)
    if (colisao){
      voltaAtorParaPosicaoinicial();
      somDaColisao.play();
      if(pontosMaiorQueZero()){
        meusPontos -= 1;
      }
    }
  }
}  
  
function voltaAtorParaPosicaoinicial(){
  yAtor = 366
}

function  exibirPontos(){
  text(meusPontos, width / 5, 29);
  textSize(30)
  textAlign(CENTER)
  fill(color (238, 59, 59))
  textStyle(BOLD)
}

function marcaPonto(){
  if (yAtor < 15){
    meusPontos += 1;
    somDoPonto.play();
    voltaAtorParaPosicaoinicial();
  }
}

function pontosMaiorQueZero(){
  return meusPontos > 0
}

function podeSeMover(){
  return yAtor < 366;
}







